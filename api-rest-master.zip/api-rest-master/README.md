# API REST

[![Run on Repl.it](https://repl.it/badge/github/salvadorhm/api-rest)](https://repl.it/github/salvadorhm/api-rest)

## Objetivo

Esta aplicación web permite mediante la URL acceder a la información almacenda en un archivo CSV.

Los datos son mostrados en formato JSON

## Acciones

* get - Obtiene todos los registros
* put - Inserta un nuevo registro
* delele - Borra un registro
* search - Busca un registro
* update - Actualiza un registro

